﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace пр15
{
    class Program
    {
        static void Main(string[] args)
        {
            HashSet<char> rusAlphabet = new HashSet<char>();
            new HashSet<char> { 'б','в', 'г' ,'д' ,'ж', 'з', 'й'};    
            Console.WriteLine("Вывести все согласные буквы");
            Print_mnozh(rusAlphabet);
            Console.ReadKey();



            private static void Print_mnozh(HashSet<char> res)
            {
                foreach (char s in res)
                    Console.Write(s);
                Console.WriteLine();
            }
        }
    }
}
