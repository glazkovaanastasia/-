﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace массивы
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Решение задач на массивы");
            Console.WriteLine("Выполнила студентка 2 курса Глазкова Анастасия");
            Console.WriteLine("№1");
            Console.Write("Введите размер массива N");
            Random rnd = new Random();
            int N = int.Parse(Console.ReadLine());
            int[] A = new int[N];
            Console.Write("Введите натуральное число K");
            int K = int.Parse(Console.ReadLine());
            long summa = 0;
            for (int i = 0; i < N; i++)
            {
                A[i] = rnd.Next(int.MaxValue);
                Console.WriteLine($"{A[i]}  ");
                if (A[i] % K == 0)
                    summa += A[i];
            }
            Console.WriteLine($"Сумма элементов, кратных {K}, равна {summa}");
            Console.ReadKey();

           
            Console.WriteLine("№2");
            Console.Write("Введите кол-во элементов последовательности");
            int[] Massiv1 = { 1, 3, -9, -5, 4, 0, -12, 3, 7 };
            int countZero = 0;
            Console.WriteLine("Массив из номеров нулей");
            foreach (int m in Massiv1)
            {
                Console.WriteLine(m);
                if (m == 0)
                    countZero++;
            }
            int[] Massiv2 = new int[countZero];
            int j = 0;
            for (int i = 0; i < Massiv1.Length; i++)
            {
                if (Massiv1[i] == 0)
                {
                    Massiv2[j] = i;
                    j++;
                }
                Console.WriteLine("Массив из номеров нулей");
                foreach (int m in Massiv2)
                {
                    Console.WriteLine(m);
                }
                Console.ReadKey();

               
                Console.WriteLine("№9");
                Random rnd1 = new Random();
                double[,] MassivD = new double[1, 0];
                for (int i1 = 1; i1 < 1; i1++)
                {
                    MassivD[i1, j] = rnd1.Next(-100, 100);
                    Console.WriteLine($"{MassivD[i1, j]}");
                }
                




            }

        } 
 }
            }
